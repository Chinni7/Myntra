# Myntra-Clone (Assignment by GoComet)

## Libraries Used: React, Redux, and AntD.

## Written in: Typescript and SCSS

## Installation


```bash
npm install
npm run start
```


## License
[MIT](https://choosealicense.com/licenses/mit/)
