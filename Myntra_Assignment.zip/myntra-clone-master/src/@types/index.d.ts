declare module "infinite-react-carousel";
