export const filterColors = [
  {
    hex: "#FFFFFF",
    name: "white",
  },
  {
    hex: "#0074d9",
    name: "Blue",
  },
  {
    hex: "#3c4477",
    name: "Navy Blue",
  },
  {
    hex: "#36454f",
    name: "Black",
  },
  {
    hex: "#5eb160",
    name: "Green",
  },
  {
    hex: "#d34b56",
    name: "Red",
  },
  {
    hex: "#f1a9c4",
    name: "Pink",
  },
  {
    hex: "#3d9970",
    name: "Olive",
  },
];
